#include "prerelease/stb_lib.h"
#define STB_LIB_IMPLEMENTATION
#include "prerelease/stb_lib.h"

//#define STB_REGEX_IMPLEMENTATION
//#include "stb_regex.h"

int main(int argc, char **argv)
{

}